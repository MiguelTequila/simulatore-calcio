"""
data_fetcher.py — Recupero dati squadre e quote.

Tre sorgenti, in ordine di priorità:
  1. API-Football (statistiche squadre: gol casa/fuori, forma, tiri)
  2. The Odds API (quote 1X2 e Under/Over 2.5)
  3. Input manuale (fallback sempre disponibile, nessuna chiave richiesta)

Nota onesta: il piano gratuito di API-Football ha limiti severi
(~100 richieste/giorno e restrizioni sulle stagioni). Il codice è
predisposto e funzionante, ma la modalità manuale è il default
consigliato per uso quotidiano.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import requests

from src import config


# ---------------------------------------------------------------------------
# STRUTTURE DATI
# ---------------------------------------------------------------------------

@dataclass
class StatisticheSquadra:
    """Statistiche essenziali di una squadra per il modello."""
    nome: str
    # Medie gol per partita nel contesto rilevante (casa per la squadra
    # di casa, trasferta per quella ospite)
    gol_fatti_media: float
    gol_subiti_media: float
    # Forma recente: lista degli ultimi 5 risultati, es. ["W","W","D","L","W"]
    forma_ultime5: list[str] = field(default_factory=list)
    # Tiri in porta medi (opzionale: raffina la stima offensiva)
    tiri_in_porta_media: float | None = None

    def punteggio_forma(self) -> float:
        """
        Converte la forma in un moltiplicatore centrato su 1.0.
        W=3, D=1, L=0 punti. 15 punti (5 vittorie) -> forma massima.
        Il range effettivo è limitato da IMPATTO_FORMA_MAX in config.
        """
        if not self.forma_ultime5:
            return 1.0
        punti = {"W": 3, "D": 1, "L": 0}
        totale = sum(punti.get(r.upper(), 1) for r in self.forma_ultime5)
        massimo = 3 * len(self.forma_ultime5)
        # Normalizzato in [-1, +1] rispetto alla media attesa (~1.4 pt/partita)
        atteso = 1.4 * len(self.forma_ultime5)
        scost = (totale - atteso) / (massimo - atteso)  # in [-inf, 1], clampato sotto
        scost = max(-1.0, min(1.0, scost))
        return 1.0 + scost * config.IMPATTO_FORMA_MAX


@dataclass
class QuoteMatch:
    """Quote decimali del bookmaker per il match."""
    quota_1: float          # vittoria casa
    quota_x: float          # pareggio
    quota_2: float          # vittoria trasferta
    quota_over25: float | None = None
    quota_under25: float | None = None

    def probabilita_implicite_1x2(self) -> tuple[float, float, float]:
        """
        Converte le quote 1X2 in probabilità "de-marginate".
        Le quote grezze sommano a >100% (il margine del bookmaker):
        normalizziamo per rimuoverlo (metodo proporzionale).
        """
        raw = [1 / self.quota_1, 1 / self.quota_x, 1 / self.quota_2]
        margine = sum(raw)
        return tuple(p / margine for p in raw)

    def probabilita_implicita_over25(self) -> float | None:
        """Probabilità de-marginata dell'Over 2.5 (None se quote assenti)."""
        if not self.quota_over25 or not self.quota_under25:
            return None
        raw_over = 1 / self.quota_over25
        raw_under = 1 / self.quota_under25
        return raw_over / (raw_over + raw_under)


# ---------------------------------------------------------------------------
# CLIENT API-FOOTBALL
# ---------------------------------------------------------------------------

class APIFootballClient:
    """Client minimale per API-Football (api-sports.io, piano free)."""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or config.API_FOOTBALL_KEY
        self.headers = {"x-apisports-key": self.api_key}

    def _get(self, endpoint: str, params: dict) -> dict:
        """Wrapper GET con gestione errori base."""
        url = f"{config.API_FOOTBALL_BASE_URL}/{endpoint}"
        resp = requests.get(url, headers=self.headers, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        if data.get("errors"):
            raise RuntimeError(f"API-Football errore: {data['errors']}")
        return data

    def cerca_team_id(self, nome_squadra: str, league_id: int, stagione: int) -> int:
        """Trova l'ID interno della squadra a partire dal nome."""
        data = self._get("teams", {
            "search": nome_squadra, "league": league_id, "season": stagione,
        })
        risultati = data.get("response", [])
        if not risultati:
            raise ValueError(f"Squadra '{nome_squadra}' non trovata.")
        return risultati[0]["team"]["id"]

    def statistiche_squadra(
        self, team_id: int, league_id: int, stagione: int, in_casa: bool,
    ) -> StatisticheSquadra:
        """
        Recupera le statistiche stagionali della squadra e le riduce
        alle sole metriche usate dal modello (contesto casa o trasferta).
        """
        data = self._get("teams/statistics", {
            "team": team_id, "league": league_id, "season": stagione,
        })
        r = data["response"]
        contesto = "home" if in_casa else "away"

        gol_fatti = float(r["goals"]["for"]["average"][contesto] or 0)
        gol_subiti = float(r["goals"]["against"]["average"][contesto] or 0)
        # La stringa "form" è tipo "WWDLW": prendiamo le ultime 5
        forma = list(r.get("form") or "")[-5:]

        return StatisticheSquadra(
            nome=r["team"]["name"],
            gol_fatti_media=gol_fatti,
            gol_subiti_media=gol_subiti,
            forma_ultime5=forma,
        )


# ---------------------------------------------------------------------------
# CLIENT THE ODDS API
# ---------------------------------------------------------------------------

class OddsAPIClient:
    """Client minimale per The Odds API (quote 1X2 pre-match)."""

    # Mappatura competizione -> sport_key di The Odds API
    SPORT_KEYS = {
        "serie a": "soccer_italy_serie_a",
        "premier league": "soccer_epl",
        "laliga": "soccer_spain_la_liga",
        "bundesliga": "soccer_germany_bundesliga",
        "ligue 1": "soccer_france_ligue_one",
    }

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or config.ODDS_API_KEY

    def quote_match(self, competizione: str, casa: str, fuori: str) -> QuoteMatch | None:
        """
        Cerca il match nelle quote disponibili e restituisce le quote 1X2
        del primo bookmaker trovato. Restituisce None se non trovato.
        """
        sport_key = self.SPORT_KEYS.get(competizione.lower())
        if not sport_key:
            return None

        url = f"{config.ODDS_API_BASE_URL}/sports/{sport_key}/odds"
        resp = requests.get(url, params={
            "apiKey": self.api_key, "regions": "eu",
            "markets": "h2h,totals", "oddsFormat": "decimal",
        }, timeout=15)
        resp.raise_for_status()

        for evento in resp.json():
            if (casa.lower() in evento["home_team"].lower()
                    and fuori.lower() in evento["away_team"].lower()):
                return self._estrai_quote(evento, evento["home_team"], evento["away_team"])
        return None

    @staticmethod
    def _estrai_quote(evento: dict, casa: str, fuori: str) -> QuoteMatch | None:
        """Estrae 1X2 e Over/Under 2.5 dal primo bookmaker dell'evento."""
        if not evento.get("bookmakers"):
            return None
        book = evento["bookmakers"][0]
        q1 = qx = q2 = None
        qo = qu = None
        for mercato in book["markets"]:
            if mercato["key"] == "h2h":
                for esito in mercato["outcomes"]:
                    if esito["name"] == casa:
                        q1 = esito["price"]
                    elif esito["name"] == fuori:
                        q2 = esito["price"]
                    else:
                        qx = esito["price"]
            elif mercato["key"] == "totals":
                for esito in mercato["outcomes"]:
                    if esito.get("point") == 2.5:
                        if esito["name"] == "Over":
                            qo = esito["price"]
                        else:
                            qu = esito["price"]
        if not all([q1, qx, q2]):
            return None
        return QuoteMatch(q1, qx, q2, qo, qu)


# ---------------------------------------------------------------------------
# INPUT MANUALE (fallback senza API)
# ---------------------------------------------------------------------------

def input_manuale_squadra(nome: str, contesto: str) -> StatisticheSquadra:
    """Raccoglie da tastiera le statistiche di una squadra."""
    print(f"\n--- Dati {nome} ({contesto}) ---")
    gf = float(input(f"Media gol FATTI a partita ({contesto}): ").replace(",", "."))
    gs = float(input(f"Media gol SUBITI a partita ({contesto}): ").replace(",", "."))
    forma = input("Forma ultime 5 (es. WWDLW, invio per saltare): ").strip().upper()
    return StatisticheSquadra(
        nome=nome, gol_fatti_media=gf, gol_subiti_media=gs,
        forma_ultime5=list(forma) if forma else [],
    )


def input_manuale_quote() -> QuoteMatch | None:
    """Raccoglie da tastiera le quote del match (invio per saltare tutto)."""
    print("\n--- Quote bookmaker (decimali, invio per saltare) ---")
    q1 = input("Quota 1 (casa): ").strip()
    if not q1:
        return None
    qx = float(input("Quota X: ").replace(",", "."))
    q2 = float(input("Quota 2 (fuori): ").replace(",", "."))
    qo = input("Quota Over 2.5 (invio per saltare): ").strip()
    qu = input("Quota Under 2.5 (invio per saltare): ").strip()
    return QuoteMatch(
        quota_1=float(q1.replace(",", ".")), quota_x=qx, quota_2=q2,
        quota_over25=float(qo.replace(",", ".")) if qo else None,
        quota_under25=float(qu.replace(",", ".")) if qu else None,
    )
